# LiterAlura

## Requisitos
- PostgreSQL instalado y ejecutando
- Base de datos creada: literalura
- Java 11+
- IntelliJ IDEA o cualquier IDE compatible

## Librerías externas (añadir desde lib/)
- jackson-core-2.16.0.jar
- jackson-databind-2.16.0.jar
- jackson-annotations-2.16.0.jar
- postgresql-42.7.3.jar

## Cómo usar
1. Abrir el proyecto en tu IDE
2. Agregar los JAR desde Project Structure > Libraries
3. Ejecutar `Main.java`
4. Interactuar con el menú en consola
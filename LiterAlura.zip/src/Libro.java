import com.fasterxml.jackson.annotation.*;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Libro {
    @JsonAlias("title")
    private String titulo;

    @JsonAlias("authors")
    private List<Autor> autores;

    private String autor;
    private int anio;

    public Libro() {}

    public Libro(String titulo, String autor, int anio) {
        this.titulo = titulo; this.autor = autor; this.anio = anio;
    }

    public String getTitulo() { return titulo; }
    public List<Autor> getAutores() { return autores; }
    public String getAutor() { return autor; }
    public int getAnio() { return anio; }

    @Override
    public String toString() {
        String nombreAutor = (autores != null && !autores.isEmpty()) ? autores.get(0).getNombre() : autor;
        return "📘 " + titulo + " - " + nombreAutor + " (" + anio + ")";
    }
}
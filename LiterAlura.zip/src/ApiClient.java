import java.net.URI;
import java.net.http.*;

public class ApiClient {
    public String buscarLibros(String consulta) throws Exception {
        String url = "https://gutendex.com/books?search=" + consulta.replace(" ", "+");
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url)).GET().build();
        HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
        return resp.body();
    }
}
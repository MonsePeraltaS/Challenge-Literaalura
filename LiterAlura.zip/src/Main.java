import com.fasterxml.jackson.databind.*;
import java.util.*;
public class Main {
    public static void main(String[] args) throws Exception {
        ApiClient api = new ApiClient();
        LibroDAO dao = new LibroDAO();
        Scanner sc = new Scanner(System.in);
        ObjectMapper mapper = new ObjectMapper();
        int op;
        do {
            System.out.println("\n=== Menú LiterAlura ===");
            System.out.println("1. Buscar libros (API y guarda)");
            System.out.println("2. Ver libros guardados");
            System.out.println("3. Buscar por autor");
            System.out.println("4. Buscar por año");
            System.out.println("5. Salir");
            System.out.print("Opción: ");
            op = sc.nextInt(); sc.nextLine();

            switch (op) {
                case 1 -> {
                    System.out.print("Buscar (título o autor): ");
                    String q = sc.nextLine();
                    JsonNode root = mapper.readTree(api.buscarLibros(q));
                    JsonNode res = root.get("results");
                    for (JsonNode n : res) {
                        Libro l = mapper.treeToValue(n, Libro.class);
                        System.out.println(l);
                        dao.guardarLibro(l);
                    }
                }
                case 2 -> dao.mostrarTodos().forEach(System.out::println);
                case 3 -> {
                    System.out.print("Autor: ");
                    dao.buscarPorAutor(sc.nextLine()).forEach(System.out::println);
                }
                case 4 -> {
                    System.out.print("Año: ");
                    dao.buscarPorAnio(sc.nextInt()).forEach(System.out::println);
                    sc.nextLine();
                }
                case 5 -> System.out.println("¡Hasta pronto!");
                default -> System.out.println("Opción inválida");
            }
        } while (op != 5);
    }
}
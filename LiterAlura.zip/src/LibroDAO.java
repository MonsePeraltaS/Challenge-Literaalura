import java.sql.*;
import java.util.*;

public class LibroDAO {
    private final Connection conn;

    public LibroDAO() throws SQLException {
        conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/literalura");
        String crear = """
            CREATE TABLE IF NOT EXISTS libros (
                id SERIAL PRIMARY KEY,
                titulo TEXT NOT NULL,
                autor TEXT,
                anio INTEGER
            );
            """;
        conn.createStatement().execute(crear);
    }

    public void guardarLibro(Libro libro) throws SQLException {
        String autor = libro.getAutores() != null && !libro.getAutores().isEmpty()
             ? libro.getAutores().get(0).getNombre() : "Desconocido";
        int anio = 0;
        String sql = "INSERT INTO libros (titulo, autor, anio) VALUES (?, ?, ?)";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, libro.getTitulo());
        st.setString(2, autor);
        st.setInt(3, anio);
        st.executeUpdate();
    }

    private List<Libro> runBusca(PreparedStatement st) throws SQLException {
        ResultSet rs = st.executeQuery();
        var lista = new ArrayList<Libro>();
        while (rs.next()) {
            lista.add(new Libro(rs.getString("titulo"), rs.getString("autor"), rs.getInt("anio")));
        }
        return lista;
    }

    public List<Libro> mostrarTodos() throws SQLException {
        return runBusca(conn.prepareStatement("SELECT * FROM libros"));
    }

    public List<Libro> buscarPorAutor(String autor) throws SQLException {
        PreparedStatement st = conn.prepareStatement("SELECT * FROM libros WHERE LOWER(autor) LIKE ?");
        st.setString(1, "%" + autor.toLowerCase() + "%");
        return runBusca(st);
    }

    public List<Libro> buscarPorAnio(int anio) throws SQLException {
        PreparedStatement st = conn.prepareStatement("SELECT * FROM libros WHERE anio = ?");
        st.setInt(1, anio);
        return runBusca(st);
    }
}